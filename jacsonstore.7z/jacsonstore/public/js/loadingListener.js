window.addEventListener('load', function() {
    this.setTimeout(()=> {
        const loading = document.querySelector('.loading');
        loading.style.display = 'none';
    }, 1500)
});