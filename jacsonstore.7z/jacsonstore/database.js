const StormDB = require("stormdb");
const fs = require('fs');
const engine = new StormDB.localFileEngine("./database/db.json");
const db = new StormDB(engine);
db.default({users: []})

const engine2 = new StormDB.localFileEngine("./database/purchases.json");
const purchases = new StormDB(engine2);
purchases.default([])

function getUserPurchases(id) {
  const fileContents = fs.readFileSync('./database/purchases.json', 'utf-8');
  const fileData = JSON.parse(fileContents);
  const user = fileData.find(user => user.id === id);
  if (user) {
    return user.purchases;
  }
  return undefined;
}

function addUserPurchases(id, pur) {
  const fileContents = fs.readFileSync('./database/purchases.json', 'utf-8');
  const fileData = JSON.parse(fileContents);
  if (!Array.isArray(fileData)) {
    return;
  }
  const userIndex = fileData.findIndex(user => user.id === id);
  if (userIndex !== -1) {
    if (!Array.isArray(fileData[userIndex].purchases)) {
      return;
    }
    fileData[userIndex].purchases.push(...pur);
  } else {
    fileData.push({ id: id, purchases: Array.isArray(pur) ? pur : [pur] });
  }
  fs.writeFileSync('./database/purchases.json', JSON.stringify(fileData));
}

function isUserLoginnedIn(req) {
    const cookieValue = req.cookies.uuid;
    if (cookieValue === undefined) return false;
    if (getUserInfo(cookieValue) === undefined) return false;
    return true;
}

function getUserInfo(uuid) {
    const fileContents = fs.readFileSync('./database/db.json', 'utf-8');
    const fileData = JSON.parse(fileContents);
    const users = fileData.users || []; // default empty array if users is not present
    for (let i = 0; i < users.length; i++) {
        const user_data = users[i];
        if (user_data.uuid === uuid) {
            return user_data;
        }
    }
}

const DB_FILE_PATH = './database/db.json';

function putIntoDatabase(data) {
  const existingUsers = getUsers().filter(user => user.id === data.id);
  if (existingUsers.length > 0) {
    const updatedUsers = getUsers().filter(user => user.id !== data.id);
    updatedUsers.push(data);
    saveUsers(updatedUsers);
  } else {
    const users = getUsers();
    users.push(data);
    saveUsers(users);
  }
}




function getUsers() {
  try {
    const fileContents = fs.readFileSync(DB_FILE_PATH, 'utf-8');
    return JSON.parse(fileContents).users || []; // default empty array if users is not present
  } catch (err) {
    
    return [];
  }
}

function saveUsers(users) {
  try {
    fs.writeFileSync(DB_FILE_PATH, JSON.stringify({users}));
  } catch (err) {
    
  }
}

module.exports = {
    isUserLoginnedIn,
    getUserInfo,
    putIntoDatabase,
    getUserPurchases,
    addUserPurchases
};
