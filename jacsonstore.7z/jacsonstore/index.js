const Discord = require('discord.js');

const { Client, GatewayIntentBits, ButtonBuilder, ButtonStyle, Events, ActionRowBuilder,  StringSelectMenuBuilder ,PermissionsBitField} = require('discord.js');
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers
    ],
});

const express = require("express");
const cookieParser = require('cookie-parser');
const app = express();

app.set('view engine', 'ejs')
app.use(express.static(__dirname + '/public'));
app.use(cookieParser());

const unirest = require('unirest');
const {isUserLoginnedIn, putIntoDatabase, getUserInfo, addUserPurchases, getUserPurchases} = require('./database')

const { v4: uuidv4 } = require('uuid');
const { use } = require('passport');

//Controllers--------------------------------------------------------------------------------------
app.get('/', (req, res) => {
    const guild = client.guilds.cache.get('1092436453616795688');
    const channel = guild.channels.cache.get('1092436454120099842');
    
    let reviews = [];
    channel.messages.fetch().then(messages => {
      messages.forEach(message => {
        reviews.push({
          avatar: message.author.avatarURL(),
          username: message.author.username,
          message: message.content
        });
      });
      
      res.render('index', {
        title: guild.name,
        avatar: guild.iconURL(),
        memberCount: guild.memberCount,
        boosts: guild.premiumSubscriptionCount,
        reviews: reviews
      });
    }).catch(err => {
      console.error(err);
      res.render('error', { message: 'Error fetching messages' });
    });
});

app.get('/login', (req, res) => {
    if (isUserLoginnedIn(req)) {
        res.cookie('uuid', "null", { maxAge: 9000000, httpOnly: false })
    }
    res.redirect('https://discord.com/api/oauth2/authorize?client_id=1092437949154611331&redirect_uri=http%3A%2F%2Flocalhost%2Fauth%2Fdiscord%2Fcallback&response_type=code&scope=identify%20guilds.join')
})

app.get('/auth/discord/callback', (req, res)=> {
    if (!req.query.code) { res.render('error'); return; }
    const clientId = '1092437949154611331'
    const clientSecret = '8gKCQxxU-J-UzmiO-SUbVChW0vCK2YLT'
    const redirectUrl = 'http://localhost/auth/discord/callback';
    let requestPayload = {grant_type: 'authorization_code', code: req.query.code,redirect_uri: redirectUrl,client_id: clientId, client_secret: clientSecret,};

    unirest.post('https://discord.com/api/oauth2/token').send(requestPayload).headers({'Content-Type': 'application/x-www-form-urlencoded','User-Agent': 'DiscordBot'})
    .then((data) => {
        unirest.get("https://discordapp.com/api/users/@me").headers({"Authorization": `${data.body.token_type} ${data.body.access_token}`})
        .then((user)=> {
            unirest.put(`https://discordapp.com/api/guilds/1092436453616795688/members/${user.body.id}`)
            .headers({"Authorization": `Bot MTA5MjQzNzk0OTE1NDYxMTMzMQ.GIVN7w.FUFA21Fhhf4nGinklC1PSMhBx89KYnH36e3_BY`, "Content-Type": "application/json"})
            .send({ "access_token": `${data.body.access_token}` })
            .then(()=> {
                const uuid = uuidv4();
                res.cookie('uuid', uuid, { maxAge: 9000000, httpOnly: false })
                const data_to_put = { uuid: uuid, discord_id: user.body.id }
                putIntoDatabase(data_to_put);
                addUserPurchases(user.body.id, 0)
                res.redirect('/auth/succesfull') 
            })
        });
    });
})

app.get('/auth/succesfull', (req, res)=> {
    if (isUserLoginnedIn(req)) {
        const userData = getUserInfo(req.cookies.uuid)
        client.users.fetch(userData.discord_id).then(discord_user=> {
            const guild = client.guilds.cache.get('1092436453616795688');
            let discordAvatar;
            if (discord_user.avatarURL() === null) discordAvatar = 'https://cdn.discordapp.com/attachments/1060583077774114816/1093565018370494534/40a4592d0e7f4dc067ec0cdc24e038b9.png'; else discordAvatar = discord_user.avatarURL();
            res.render('successLogin', {
                title: guild.name,
                avatar: guild.iconURL(),
                memberCount: guild.memberCount,
                boosts: guild.premiumSubscriptionCount,
                username: discord_user.username,
                discrim: discord_user.discriminator,
                avatar_url: discordAvatar
            })
        })
    } else {
        res.redirect('/login')
    }
})

app.get('/logout', (req, res) => {
    const guild = client.guilds.cache.get('1092436453616795688');
    if (isUserLoginnedIn(req)) {
        res.render('logout', {
            title: guild.name,
            avatar: guild.iconURL(),
            memberCount: guild.memberCount,
            boosts: guild.premiumSubscriptionCount
        })
    } else {
        res.redirect('/', {
            title: guild.name,
            avatar: guild.iconURL(),
            memberCount: guild.memberCount,
            boosts: guild.premiumSubscriptionCount
        })
    }
})

app.get('/remove/cookies', (req, res)=> {
    res.cookie('uuid', "null", { maxAge: 9000000, httpOnly: false })
    res.redirect('/')
})

app.get('/me', (req, res)=> {
    const guild = client.guilds.cache.get('1092436453616795688');
    if (isUserLoginnedIn(req)) {
        const userData = getUserInfo(req.cookies.uuid)
        client.users.fetch(userData.discord_id).then(discord_user=> {
            let discordAvatar;
            if (discord_user.avatarURL() === null) discordAvatar = 'https://cdn.discordapp.com/attachments/1060583077774114816/1093565018370494534/40a4592d0e7f4dc067ec0cdc24e038b9.png'; else discordAvatar = discord_user.avatarURL();
            res.render('me', {
                title: guild.name,
                avatar: guild.iconURL(),
                memberCount: guild.memberCount,
                boosts: guild.premiumSubscriptionCount,
                username: discord_user.username,
                discrim: discord_user.discriminator,
                avatar_url: discordAvatar,
                purchases: getUserPurchases(userData.discord_id)
            });
        })
    } else {
        res.render('loginPage', {
            title: guild.name,
            avatar: guild.iconURL(),
            memberCount: guild.memberCount,
            boosts: guild.premiumSubscriptionCount
        });
    }
})

app.get('/cart', (req, res)=> {
    const guild = client.guilds.cache.get('1092436453616795688');
    if (isUserLoginnedIn(req)) {
        res.render('cart', {
            title: guild.name,
            avatar: guild.iconURL(),
            memberCount: guild.memberCount,
            boosts: guild.premiumSubscriptionCount
        });
    } else {
        res.render('cartNotAllowed', {
            title: guild.name,
            avatar: guild.iconURL(),
            memberCount: guild.memberCount,
            boosts: guild.premiumSubscriptionCount
        });
    }
})

app.get('/kits', (req, res)=> {
    const guild = client.guilds.cache.get('1092436453616795688');
    if (isUserLoginnedIn(req)) {
        res.render('kits', {
            title: guild.name,
            avatar: guild.iconURL(),
            memberCount: guild.memberCount,
            boosts: guild.premiumSubscriptionCount
        });
    } else {
        res.render('kits', {
            title: guild.name,
            avatar: guild.iconURL(),
            memberCount: guild.memberCount,
            boosts: guild.premiumSubscriptionCount
        });
    }
})


//Discord controllers------------------------------------------------------------------------------
client.on('ready', ()=> {
    console.log("Discord bot is ready!")
})



//Apps authentification-----------------------------------------------------------------------------
client.login('MTA5MjQzNzk0OTE1NDYxMTMzMQ.GIVN7w.FUFA21Fhhf4nGinklC1PSMhBx89KYnH36e3_BY')
app.listen(80, () => console.log(`Listening port: 80`));